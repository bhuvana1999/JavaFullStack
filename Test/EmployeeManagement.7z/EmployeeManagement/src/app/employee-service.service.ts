import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {
  http: HttpClient;
  employeeobj: Employee[] = [];
  constructor(http: HttpClient) {
    this.http = http;
  }
  /*
  Method to fetch data from employee array
  */
  fetched: boolean = false;
  fetchDetails() {
    this.http.get('./assets/Employee.json')
      .subscribe(data => {
        if (!this.fetched) {
          this.convert(data);
          this.fetched = true;
        }
      });
  }
  /*
 Method to get data from employee array
 */
  getDetails(): Employee[] {
    return this.employeeobj;
  }
  /*
 Method to convert data
 */
  convert(data: any) {
    for (let o of data) {
      let e = new Employee(o.id, o.employeeName, o.email, o.phoneNo)
      /* To push values into the employee array object*/
      this.employeeobj.push(e);
    }
  }
  /*Delete operation to delete a row from table*/
  delete(id: number) {
    let foundIndex: number = -1;
    for (let i = 0; i < this.employeeobj.length; i++) {
      let d = this.employeeobj[i];
      if (id == d.id) {
        foundIndex = i;
        break;
      }
    }
    /*
    To delete particular row and to dispaly other rows
    */
    this.employeeobj.splice(foundIndex, 1);
  }
  add(e: Employee) {
    /* To push values into the employee array object*/
    this.employeeobj.push(e);
  }


}
export class Employee {
  id: number;
  employeeName: string;
  email: string;
  phoneNo: number
  constructor(id: number, employeeName: string, email: string, phoneNo: number) {
    this.id = id;
    this.employeeName = employeeName;
    this.email = email;
    this.phoneNo = phoneNo;

  }
}
