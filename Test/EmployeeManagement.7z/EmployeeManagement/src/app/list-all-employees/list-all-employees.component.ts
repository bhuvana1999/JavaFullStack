import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService, Employee } from '../employee-service.service';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
  serviceobj: EmployeeServiceService;

  constructor(serviceobj: EmployeeServiceService) {
    this.serviceobj = serviceobj;
  }
  employeeobj: Employee[] = [];
  /*
  Method to delete a row from table
  */
  delete(id: number) {
    this.serviceobj.delete(id);
    this.employeeobj = this.serviceobj.getDetails();
  }
  ngOnInit() {
    /* method to fetch a data from service*/
    this.serviceobj.fetchDetails();
    /* method to get a employee details*/
    this.employeeobj = this.serviceobj.getDetails();
  }

}
