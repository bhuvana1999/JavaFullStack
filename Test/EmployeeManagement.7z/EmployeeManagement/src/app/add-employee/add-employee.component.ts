import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  serviceobj: EmployeeServiceService;

  constructor(serviceobj: EmployeeServiceService) {
    this.serviceobj = serviceobj;
  }
  employeeobj: Employee[] = [];
  createdFlag: boolean = false;
  createdDepartment: Employee;
  /* method to add employee details to the table*/
  add(data: any) {
    this.createdDepartment = new Employee(data.id, data.employeeName, data.email, data.phoneNo);
    this.serviceobj.add(this.createdDepartment);

    alert("Added Succesfully!!!");
    /* method to indicate alert message if it is added*/

    this.createdFlag = true;
  }

  ngOnInit() {
  }

}
