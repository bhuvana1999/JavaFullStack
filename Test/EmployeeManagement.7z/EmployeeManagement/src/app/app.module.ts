import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListAllEmployeesComponent } from './list-all-employees/list-all-employees.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { FormsModule } from '@angular/forms';
import { HttpClient,HttpClientModule }from '@angular/common/http';
import { EmployeeServiceService } from './employee-service.service';
@NgModule({
  declarations: [
    AppComponent,
    ListAllEmployeesComponent,
    AddEmployeeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,EmployeeServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
