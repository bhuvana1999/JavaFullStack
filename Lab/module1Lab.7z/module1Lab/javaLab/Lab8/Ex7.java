package Lab8;

import java.util.Scanner;

public class Ex7 {
public static void main(String[] args) {
	boolean val=false;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter name");
	String name=sc.nextLine();
	name +="_job";
	int i=name.indexOf("_");
	String s=name.substring(0,i);
	System.out.println(s);
	val=validate(s);
	if(val==true)
	{
		System.out.println("valid name "+name);
	}
	else
	{
		System.out.println("Invalid name");
	}
}
	
static boolean validate(String name)
{
	boolean res=false;
	if(name.length()<8)
	{
		res=false;
	}
	else
	{
		res=true;
	}
	return res;
}

}
