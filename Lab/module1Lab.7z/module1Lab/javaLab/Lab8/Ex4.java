package Lab8;

import java.io.File;
import java.io.IOException;

public class Ex4 {
	public static void main(String[] args) throws IOException
	{
		File f= new File("exercise2.txt");
		System.out.println("This file is "+(f.exists()?"Exist":"Doesn't Exist"));
		System.out.println(" is readable? "+f.canRead());
		System.out.println("is writable? "+f.canWrite());
		
		System.out.println("File length " +f.length()+ " bytes");
		//System.out.println("type of the file: "+f.substring(f.lastIndexOf("."));
		

}
}
