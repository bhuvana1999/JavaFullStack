package Lab8;

import java.util.Arrays;
import java.util.Scanner;

public class Ex5 {
static boolean Alphabatic(String s)
{
	int n=s.length();
	char ch[]=new char[n];
	for(int i=0;i<n;i++)
	{
		ch[i]=s.charAt(i);
	}
	Arrays.sort(ch);
	for(int i=0;i<n;i++)
	{
		if(ch[i] !=s.charAt(i))
			return false;
	}
	return true;
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter string");
	String s=sc.nextLine();
	Ex5.Alphabatic(s);
	if(Alphabatic(s))
	{
		System.out.println("positive string");
	}
	else
	{
		System.out.println("negative String");
	}
}
}
