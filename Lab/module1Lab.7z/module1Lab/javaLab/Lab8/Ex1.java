package Lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Ex1 {
public static void main(String[] args) {
	int n;
	int sum=0;
	Scanner sc=new Scanner (System.in);
	System.out.println("enter n values");
	String s=sc.nextLine();
	StringTokenizer st=new StringTokenizer(s," ");
	while(st.hasMoreTokens())
	{
		String tem=(st.nextToken());
		n=Integer.parseInt(tem);
		System.out.println(n);
		sum +=n;
	
	}
	System.out.println("sum="+sum);
}
}
