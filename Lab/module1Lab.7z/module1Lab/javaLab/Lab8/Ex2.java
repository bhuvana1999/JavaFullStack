package Lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Ex2 {
	public static void main(String[] args) throws IOException {
		
	FileWriter fw=new FileWriter("exercise1.txt");
	PrintWriter out=new PrintWriter(fw);
	out.println("hiii");
	out.println("hello");
	out.println("welcome");
	out.println("bhuvana");
	out.flush();
	out.close();
	fw.close();
	
	int i=1;
	FileReader fr1= new FileReader("exercise1.txt");
	BufferedReader br=new BufferedReader(fr1);
	String line=br.readLine();
	while(line !=null)
	{
		System.out.println(i+" "+line);
		line=br.readLine();
		i++;
	}
	fr1.close();
	br.close();
}
}