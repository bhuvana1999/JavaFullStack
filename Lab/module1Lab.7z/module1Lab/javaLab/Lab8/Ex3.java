package Lab8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Ex3 {
	public static void main(String[] args) throws IOException {
		
		FileWriter fw=new FileWriter("exercise2.txt");
		PrintWriter out=new PrintWriter(fw);
		out.println("welcome to java prgm");
		out.println("hi bhuvana");
		out.println("how was your day");
		out.flush();
		out.close();
		fw.close();
		
		
		
		int charCount=0;
		int wordCount=0;
		int lineCount=0;
		FileReader fr1= new FileReader("exercise2.txt");
		BufferedReader br=new BufferedReader(fr1);
		String line=br.readLine();
		
		while(line !=null)
		{
			lineCount++;
			String[] words=line.split(" ");
			wordCount=wordCount+words.length;
			for(String word:words)
			{
				charCount +=words.length;
			}
			System.out.println(line);
			line=br.readLine();
			
		}
		
		System.out.println("no of lines="+lineCount);
		System.out.println("no of words="+wordCount);
		System.out.println("no of char="+charCount);
		fr1.close();
		br.close();
}
}
