package lab2;


  public abstract class Item {
	private int idNum,noOfCopies;
	private String title;

	public String toString()
	{
		return "Item [idNum= "+idNum+", noOfCopies= "+noOfCopies+", title= "+title+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", getTitle()= "+getTitle()+", getClass()= "+getClass()+", hashCode()= "+hashCode()+", toString()= "+super.toString()+"]";
	}

	Item()
	{

	}

	Item(int idNum,int noOfCopies,String title)
	{
		this.idNum=idNum;
		this.noOfCopies=noOfCopies;
		this.title=title;
	}

	public int getIdNum() {
		return idNum;
	}

	public void setIdNum(int idNum) {
		this.idNum = idNum;
	}

	public int getNoOfCopies() {
		return noOfCopies;
	}

	public void setNoOfCopies(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	void addItem(int idNum,int noOfCopies,String title)
	{
		this.idNum=idNum;
		this.noOfCopies=noOfCopies;
		this.title=title;
	}

}


 class WrittenItem extends Item{
	WrittenItem(int idNum,int noOfCopies,String title)
	{
		super(idNum,noOfCopies,title);
	}

	public WrittenItem()
	{

	}

	private String author;

	public String getAuthor()
	{
		return author;
	}

	public void setAuthor(String author)
	{
		this.author=author;
	}

	public String toString()
	{
		return "WrittenItem [author= "+author+", getAuthor= "+getAuthor()+", toString()= "+super.toString()+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", getTitle()= "+getTitle()+", getClass()= "+getClass()+", hashCode()= "+hashCode()+" ]";
	}

}



 class Book extends WrittenItem{

	Book(int idNum,int noOfCopies,String title)
	{
		super(idNum,noOfCopies,title);
	}

	Book()
	{

	}

	public static void main(String[] args)
	{

	}

	public String getAuthor()
	{
		return super.getAuthor();
	}

	public void setAuthor(String author)
	{
		super.setAuthor(author);
	}

	public String toString()
	{
		return "Book [getAuthor()= "+getAuthor()+", toString()= "+super.toString()+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", getTitle()= "+getTitle()+", getClass= "+getClass()+", hashCode()= "+hashCode()+" ]";
	}

}


 class JournalPaper extends WrittenItem{
	JournalPaper(int idNum,int noOfCopies,String title)
	{
		super(idNum,noOfCopies,title);
	}

	public JournalPaper()
	{

	}

	private String yearPublished;

	public String getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(String yearPublished) {
		this.yearPublished = yearPublished;
	}

	public String getAuthor()
	{
		return super.getAuthor();
	}

	public void setAuthor(String author)
	{
		super.setAuthor(author);
	}

	public String toString()
	{
		return "JournalPaper [yearPublished= "+yearPublished+", getYearPublished()= "+getYearPublished()+", getAuthor()= "+getAuthor()+", toString()= "+super.toString()+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", getTitle()= "+getTitle()+", getClass= "+getClass()+", hashCode()= "+hashCode()+" ]";
	}

}



 class MediaItem extends Item{
	MediaItem(int idNum,int noOfCopies,String title)
	{
		super(idNum,noOfCopies,title);
	}

	public String toString()
	{
		return "MediaItem [runTime= "+runTime+", getRunTime()= "+getRunTime()+", toString()= "+super.toString()+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", getTitle()= "+getTitle()+", getClass()= "+getClass()+", hashCode()= "+hashCode()+" ]";
	}

	private int runTime;

	public int getRunTime() {
		return runTime;
	}

	public void setRunTime(int runTime) {
		this.runTime = runTime;
	}
}




class Video extends MediaItem{
	Video(int idNum,int noOfCopies,String title)
	{
		super(idNum,noOfCopies,title);
	}

	public String toString()
	{
		return "Video [director= "+director+", genre()= "+genre+", yearReleased()= "+yearReleased+", getDirector()= "+getDirector()+", getGenre()= "+getGenre()+", getYearReleased()= "+getYearReleased()+", toString()= "+super.toString()+", getRunTime= "+getRunTime()+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", getTitle()= "+getTitle()+", getClass= "+getClass()+", hashCode()= "+hashCode()+" ]";
	}

	private String director,genre,yearReleased;

	public String getDirector() {
		return director;
	}

	public void setDirector(String getDirector) {
		this.director = getDirector;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getYearReleased() {
		return yearReleased;
	}

	public void setYearReleased(String yearReleased) {
		this.yearReleased = yearReleased;
	}



}






 class CD extends MediaItem{
	CD(int idNum,int noOfCopies,String title)
	{
		super(idNum,noOfCopies,title);
	}

	private String artist,genre;

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public int getRunTime()
	{
		return super.getRunTime();
	}

	public void setRunTime(int runTime)
	{
		super.setRunTime(runTime);
	}

	public String toString()
	{
		return "CD [artist= "+artist+", genre= "+genre+", getGenre()= "+getGenre()+", getArtist()= "+getArtist()+", getRunTime()= "+getRunTime()+", getIdNum()= "+getIdNum()+", getNoOfCopies()= "+getNoOfCopies()+", toString()= "+super.toString()+", getClass()= "+getClass()+", hashCode()= "+hashCode()+"]";
	}

	public int getIdNum()
	{
		return super.getIdNum();
	}

	public void setIdNum(int idNum)
	{
		super.setIdNum(idNum);
	}

	public int getNoOfCopies()
	{
		return super.getNoOfCopies();
	}

	public void setNoOfCopies(int noOfCopies)
	{
		super.setNoOfCopies(noOfCopies);
	}

	public String getTitle()
	{
		return super.getTitle();
	}

	public void setTitle(String Title)
	{
		super.setTitle(Title);
	}

	void addItem(int idNum,int noOfCopies,String title)
	{
		super.addItem(idNum, noOfCopies, title);
	}

}

 






