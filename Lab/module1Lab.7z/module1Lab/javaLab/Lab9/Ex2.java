package Lab9;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Ex2 {
	 static void countCharacter(char[] c2) 
	    { 
			Ex2 e=new Ex2();
		 HashMap<Character, Integer> hm = new HashMap<Character, Integer>(); 
	//	 char[] strArray = c2.toCharArray(); 
		 for (char c : c2)
		 {
	            if (hm.containsKey(c)) { 
	            	hm.put(c, hm.get(c) + 1); 
	            }
	            else { 
	            	  hm.put(c, 1);
	            }
		 
	    }
		 for (Map.Entry entry : hm.entrySet()) { 
	            System.out.println(entry.getKey() + " " + entry.getValue());
	        } 
	    } 
	 public static void main(String[] args) 
	    { 
	       Scanner sc=new Scanner(System.in);
	       char[] c= {'a','p','p','l','e'};
	       System.out.println(c);
	        countCharacter(c); 
	    } 
	} 