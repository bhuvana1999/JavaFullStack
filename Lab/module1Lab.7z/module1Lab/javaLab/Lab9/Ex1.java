package Lab9;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
class Datas
{
	private int id;
	private String name;
	public Datas(int id, String name) {
		super();
		this.id = id;
		this.setName(name);
	}
	@Override
	public String toString() {
		return "Datas [id=" + id + ", name=" + getName() + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}

public class Ex1 {
	ArrayList getValues(HashMap mp)
	{
	Collection values=mp.values();
	ArrayList al=new ArrayList(values);
	return al;
	}	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Ex1 e=new Ex1();
	Datas d=new Datas(12,"durga");
	Datas d1=new Datas(3,"bhuvana");
	Datas d2=new Datas(1,"siva");
	Datas d3=new Datas(60,"venda");
	HashMap hm=new HashMap();
	hm.put(1,d);
	hm.put(2,d1);
	hm.put(3,d2);
	hm.put(4,d3);
	System.out.println(e.getValues(hm));
	
}
}
class Mycomparator implements Comparator
{
	public int compare(Object o1,Object o2)
	{
		Datas e1=(Datas) o1;
		String s1=e1.getName();
		Datas e2=(Datas) o2;
		String s2=e2.getName();
		return s1.compareTo(s2);
		
	}


}
