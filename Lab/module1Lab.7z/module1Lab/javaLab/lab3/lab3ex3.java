package lab3;

import java.util.Arrays;
import java.util.Scanner;

public class lab3ex3 {
public static void main(String[] args) {
	System.out.println("enter n");
	Scanner sc=new Scanner(System.in); 
	int n= sc.nextInt();
	int a[]=new int[n];
	System.out.println("enter numbers");
	for(int i=0;i<=n;i++)
	{
		a[i]=sc.nextInt();
	}
	int b[]=new int [n];
	int j=0,k = 0;
	int temp;
	for(int c=n-1; c>=0;c--)
	{
		b[j]=a[c];
		j++;
	}
	System.out.println("reversed order");
	for(int p=0;p<n;p++)
		System.out.println(b[p]);
	for( j=0;j<n;j++)
	{
		for(int l=k+1;l<n;l++)
		{
			if(b[k]>b[l]);
			{
				temp=b[k];
				b[k]=b[l];
				b[l]=temp;
			}
		}
	}
	System.out.println("sorted order");
	for( k=0;k<n;k++)
		System.out.println(b[k]);
}
}
