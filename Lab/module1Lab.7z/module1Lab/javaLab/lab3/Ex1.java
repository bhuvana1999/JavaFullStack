package lab3;
import java.util.Scanner;

public class Ex1 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter n value");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the numbers");
		for(int k=0;k<n;k++)
		{
			a[k]=sc.nextInt();
		}
		
		int temp;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<=n;j++)
			{
				if(a[i]<a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
					
			}
		}
		for(int i=0;i<n;i++)
		{
			if(a[i]==a[1])
			{
				System.out.println("ans"+a[1]);
			}
			
		}
	}

}
