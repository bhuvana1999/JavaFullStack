package lab3;
import java.util.Arrays;
import java.util.Scanner;

public class Lab3Ex2 {
 public static String SortString(String inputString)
	{
		char tempArray[]=inputString.toCharArray(); 
		Arrays.sort(tempArray);
		return new String (tempArray);
	}	
	
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a String");
		String str=sc.nextLine();
		str=SortString(str);
		int n=str.length();
		String s1=null;
		String s2=null;
		String s3=null;
		String s4=null;
		 String str1="";
		 String str2="";
		 String str3="";
		 String str4="";
		
		if(n%2==0)
		{
			for(int i=0;i<n;i++)
				{
				if(i<n/2)
				{
					str1+=str.charAt(i);
					s1=str1.toUpperCase();
				}
				else
				{
					str2+=str.charAt(i);
					s2=str2.toLowerCase();
				}
				}
				System.out.println(s1);
                System.out.println(s2);
				
		}
		else
		{
			for(int i=0;i<n;i++)
			{
			if(i<n/2+1)
			{
				str3+=str.charAt(i);
				s3=str3.toUpperCase();
			}
			else
			{
				str4+=str.charAt(i);
				s4=str4.toLowerCase();
			}
			}
			System.out.println(s3);
            System.out.println(s4);
			
		}
		
	}

}
