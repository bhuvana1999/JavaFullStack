package lab1;
import java.util.Scanner;

public class Ex4 {
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m;
		m=n/2;
	 	   if(m%2==0)
	 	   {
	 		   boolean val=true;
	 	  System.out.println(n+" is power of two");
	 	   }
	 	   else
	 	   {
	 		  boolean val=false;
	 		  System.out.println(n+" is not a power of two");
	 		   
	 	   }
	}
}
