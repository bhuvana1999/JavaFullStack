package lab1;
import java.util.Scanner;
public class Ex2 {
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int sum=caldiff(n);
		System.out.println(sum);
	}
	static int caldiff(int n)
	{
		int p,sum1=0;
		int d,sum2=0;
		int diff=0;
		for(int i=1;i<=n;i++)
		{
			p=i*i;
			sum1=sum1+p;
		}
		for(int i=1;i<=n;i++)
		{
			sum2=sum2+i;
		}
		d=sum2*sum2;
		diff=sum1-d;
		return diff;
	}

}
