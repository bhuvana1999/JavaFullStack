package lab1;

import java.util.Scanner;

public class Ex3 
{
  public static void main(String[] args) 
    {
	  Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int i=0;
		int p=n;
		int l=n;
		while(p>0)
		{
			p=p/10;
			i++;
		}
		boolean val=true;
		for(int j=0;j<=n;j++)
		{
		while(n>0)
		{
			int m=n%10;
			n=n/10;
			int q=n;
			int k=q%10;
			if(k>m)
			{
				j=i+1;
				val=false;
				break;
			}
		}
	
        }
}
}
