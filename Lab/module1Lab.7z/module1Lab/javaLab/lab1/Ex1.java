package lab1;
import java.util.Scanner;

public class Ex1 
{
   public static void main(String[] args)
   {
    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int sum=calsum(n);
    System.out.println(sum);
   }
    static int calsum(int n)
    {
    	int i;
 	   int sum=0;
         for(i=0;i<=n;i++)
         {
           if(i%3==0 || i%5==0)
           {
            sum=sum+i;
           }
         }
    return sum;
   }
}  