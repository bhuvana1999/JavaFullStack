package lab5;

import java.util.Scanner;
class FabinacciException extends Exception
{
	private int n;

	public FabinacciException(int n) {
		super();
		this.n = n;
	}
	
}

public class lab5Ex2 {
	static void number (int n) throws FabinacciException
	{
		int a=1;
		int b=1;
		int c=0;
		for(int i=1;i<=n;i++)
		{
			a=b;
			b=c;
			c=a+b;
			System.out.println(c);
		}
		
	}
public static void main(String[] args) throws FabinacciException {
	int a=1;
	int b=1;
	int c=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter n");
	int n=sc.nextInt();
		lab5Ex2.number(n);
	}
	
     }

