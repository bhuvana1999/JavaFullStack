package lab5;

import java.util.Scanner;

class EmployeesException extends Exception
{
	private String Fname;
	private String Lname;

	public EmployeesException(String Fname, String Lname) {
		this.Fname = Fname;
		this.Lname = Lname;
	}

	@Override
	public String toString() {
		return "name should not be blank";
	}
	
	
}
public class Lab5ex4 {
	static void validation(String Fname,String Lname) throws EmployeesException
	{
		if (Fname==" " || Lname==" ")
		{
			
			throw new EmployeesException(Fname,Lname);
		}
		else
		{
			System.out.println(Fname+" "+Lname);
		}
	}
	public static void main(String[] args) throws EmployeesException{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first name");
		String Fname=sc.nextLine();
		System.out.println("enter last name");
		String Lname=sc.nextLine();
		Lab5ex4.validation(Fname, Lname);
		
	}

}
