package lab5;

import java.util.Scanner;
class MyException extends Exception
{
	private int age;

	public MyException(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Age of the Person should be above 15";
	}
	
}
public class lab5ex5 {
	static void validation(int age) throws MyException
	{
		 if(age<15)
	     {    
         throw new MyException(age);
	      }  
		 else
		 {
			 System.out.println("you are eligible");
		 }
	}
	public static void main(String[]args) throws MyException{

	      Scanner sc= new Scanner (System.in);
	      System.out.println("Enter age");
	      int age = sc.nextInt();  
	      lab5ex5.validation(age);
	    	    	
	              
}
}