package lab5;
import java.util.Scanner;

public class Ex1 
	{
		public static void main(String[] args) {
			String color;
			Scanner sc=new Scanner(System.in);
			System.out.println("enter option");
			color=sc.next();
			switch (color)
			{
			case "red":
				System.out.println("stop");
				break;
			case "yellow":
				System.out.println("ready");
				break;
			case "green":
				System.out.println("go");
				break;
			default:
				System.out.println("wrong selection");
				break;
			}
			sc.close();
		}
		
		}
	
	
	
	