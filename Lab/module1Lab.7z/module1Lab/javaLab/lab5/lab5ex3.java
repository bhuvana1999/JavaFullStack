package lab5;

import java.util.Scanner;

class PrimeException extends Exception {
	private int n;

	public PrimeException(int n)
	{
		this.n=n;
	}
}
	public class lab5ex3  {
	static void number(int n) throws PrimeException{
		System.out.println("prime numbers are");
		
		 for(int i=2;i<n;i++)
	     {
	       int  c=0;
	         for(int j=1;j<=i;j++)
	         {
	        	     if(i%j==0)
	        	     {
	        	         c++;
	        	     }
	         }
	         
	       if(c==2)
	       {
	             System.out.print(i+" ");
	         }
			
				
		}
	}
	public static void main(String[] args) throws PrimeException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n");
		int n=sc.nextInt();
		lab5ex3.number(n);
	}

}
