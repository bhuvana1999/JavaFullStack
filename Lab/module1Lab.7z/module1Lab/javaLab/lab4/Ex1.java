package lab4;
import java.util.Scanner;

public class Ex1 
{
	public static void main(String[] args) 
	{
		int sum=0,r,num;
		System.out.println("enter number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		while(n>0)
		{
			num=n%10;
			r=num=num*num*num;
			sum=sum+r;
			n=n/10;
		}
		System.out.println(sum);
	}

}
