package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends Exception{
	private float salary;

	public EmployeeException(float salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "you are not eligble for grade"+salary;
	}	
	
}
public class lab5ex6 {
	static void validation(float salary) throws EmployeeException
	{
		if(salary<3000)
		{
			throw new EmployeeException(salary);
		}
		else 
		{
			System.out.println("you are eligible for grade1");
		}
	}
	public static void main(String[] args) throws EmployeeException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter name");
		String name=sc.nextLine();
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter salary");
		float salary=sc.nextFloat();
		System.out.println("name" +name);
		System.out.println("id" +id);
		System.out.println("salary" +salary);
		lab5ex6.validation(salary);
		
	}

}
