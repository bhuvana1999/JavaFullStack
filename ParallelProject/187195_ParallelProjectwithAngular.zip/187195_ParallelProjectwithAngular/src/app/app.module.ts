import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AddComponent } from './Registrations/add/add.component';
import { ListComponent } from './log/list/list.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MyServiceService } from './Service/my-service.service';
import { ShowComponent } from './Functions/show/show.component';

import { WithdrawComponent } from './Functions/withdraw/withdraw.component';
import { TransferComponent } from './Functions/transfer/transfer.component';
import { StatementComponent } from './Functions/statement/statement.component';

import { DepositeComponent } from './Functions/deposite/deposite.component';
import { HpageComponent } from './hpage/hpage.component';


@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
    ListComponent,
    ShowComponent,
    DepositeComponent,
    WithdrawComponent,
    TransferComponent,
    StatementComponent,
    HpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
