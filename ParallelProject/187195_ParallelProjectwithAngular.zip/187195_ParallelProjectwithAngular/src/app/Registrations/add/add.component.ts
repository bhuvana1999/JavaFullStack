import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { Customer } from 'src/app/Models/Customer';
import { MyServiceService } from 'src/app/Service/my-service.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  createdEmployee:Customer;
  createdTransaction:Transactions;
  createdFlag:boolean=false;
  router:Router;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }


  add(data:any){
    data.account=data.phone;
    data.balance=5000;
    this.createdEmployee=new Customer(data.account,data.name,data.phone,data.password,data.city,data.balance);
    this.service.add(this.createdEmployee);
    this.createdTransaction=new Transactions("125",data.account,"",data.balance,"Account Creation");
    this.service.addTransaction(this.createdTransaction)
    alert("Added Succesfully!!!\nYour Account No. is : "+data.account);
    this.createdFlag=true;
    this.router.navigate(['app-list']);
  }

  ngOnInit(){
  }

}
