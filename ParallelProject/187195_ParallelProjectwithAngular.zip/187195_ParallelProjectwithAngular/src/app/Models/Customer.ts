export class Customer{
    account:number;
    name:string;
    phone:number;
    password:string;
    city:string;
    balance:number;
  
  
      constructor(account:number,name:string,phone:number,password:string,city:string,balance:number)
      {
        this.balance=balance;
        this.account=account;
        this.name=name;
        this.phone=phone;
        this.password=password;
        this.city=city;
      }
  }