import { Component, OnInit, APP_INITIALIZER } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';

@Component({
  selector: 'app-deposite',
  templateUrl: './deposite.component.html',
  styleUrls: ['./deposite.component.css']
})
export class DepositeComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  createdTransaction:Transactions;
  router:Router;

  service:MyServiceService;
  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  deposite(data:any){
    let tid:number;
    let account_first=data.account;
    let balance=data.balance;
    var ttype:string;
    ttype="Deposite Amount"
    this.service.depositeBalance(account_first,balance);
    this.createdTransaction=new Transactions("123",data.account,"",data.balance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['app-hpage']);
  }


  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
