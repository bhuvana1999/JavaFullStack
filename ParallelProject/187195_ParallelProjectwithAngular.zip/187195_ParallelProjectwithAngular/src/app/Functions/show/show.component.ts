import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';


@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {

  isLogin:boolean=true;
  customers:Customer[]=[];
  balance:number;
  router:Router;
  isShowBalance:boolean=true;
  service:MyServiceService;

  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  show(data:any){
    this.balance=this.service.showBalance(data);
    alert("Current balance : "+this.balance)
    this.isShowBalance=!this.isShowBalance;
    this.router.navigate(['app-hpage']);
  }
          
  ngOnInit() {
    this.service.fetchCustomers();;
    this.customers=this.service.getCustomers();
  }


}
