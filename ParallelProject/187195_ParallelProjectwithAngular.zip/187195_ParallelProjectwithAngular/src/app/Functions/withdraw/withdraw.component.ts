import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/Models/Customer';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  isLogin:boolean=true;
 customers:Customer[]=[];
 createdTransaction:Transactions;
 router:Router;
 
 service:MyServiceService;
 constructor(service:MyServiceService,router:Router) { 
 this.service=service;
 this.isLogin=this.service.isLogin;
 this.router=router;
 }
 
 withdraw(data:any){
 let account_first=data.account;
 let balance=data.balance;
 var ttype:string;
 ttype="Withdraw Amount"
 
 this.service.withdrawBalance(account_first,balance);
 
 this.createdTransaction=new Transactions("123",data.account,"",data.balance,ttype);
 this.service.addTransaction(this.createdTransaction)
 this.router.navigate(['app-hpage']);
 }
 
 ngOnInit() {
 this.customers=this.service.getCustomers();
 }
}

  