import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  isLogin:boolean=true;
  createdTransaction:Transactions;
  router:Router;
  service:MyServiceService;
  
  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  fundTransfer(data:any){
    let account_first=data.account;
    let account_second=data.account_second;
    let balance=data.balance;
    var ttype:string;
    ttype="Fund Transfer"
    this.service.depositeBalance(account_second,balance);
    this.service.withdrawBalance(account_first,balance)
    this.createdTransaction=new Transactions("123",account_first,account_second,data.balance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['app-hpage']);
  }

  ngOnInit() {
  }

}
