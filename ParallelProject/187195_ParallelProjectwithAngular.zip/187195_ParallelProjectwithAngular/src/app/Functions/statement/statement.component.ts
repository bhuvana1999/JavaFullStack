import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit {

  transactions:Transactions[]=[];
  customers:Customer[]=[];
  service:MyServiceService;
  router:Router;

  constructor(service:MyServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  bStatement(data:any){
    this.transactions=this.service.bStatement(data.account);
 
     
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.customers=this.service.getCustomers();
  }

}
