import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hpage',
  templateUrl: './hpage.component.html',
  styleUrls: ['./hpage.component.css']
})
export class HpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
