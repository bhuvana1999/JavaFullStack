import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './Registrations/add/add.component';
import { ListComponent } from './log/list/list.component';
import { ShowComponent } from './Functions/show/show.component';

import { WithdrawComponent } from './Functions/withdraw/withdraw.component';
import { TransferComponent } from './Functions/transfer/transfer.component';
import { StatementComponent } from './Functions/statement/statement.component';

import { DepositeComponent } from './Functions/deposite/deposite.component';
import { HpageComponent } from './hpage/hpage.component';



const routes: Routes = [
  {
    path: 'app-add',
    component: AddComponent
  },
  {
    path: 'app-list',
    component: ListComponent
  },
  {
    path: 'app-show',
    component: ShowComponent
  },
  {
    path: 'app-hpage/app-show',
    component: ShowComponent
  },
  {
    path: 'app-deposite',
    component: DepositeComponent
  },
  {
    path: 'app-hpage/app-deposite',
    component: DepositeComponent
  },
  {
    path: 'app-withdraw',
    component: WithdrawComponent
  },
  {
    path: 'app-hpage/app-withdraw',
    component: WithdrawComponent
  },
  {
    path: 'app-hpage/app-transfer',
    component: TransferComponent
  },
  {
    path: 'app-transfer',
    component: TransferComponent
  },
  {
    path: 'app-hpage/app-statement',
    component: StatementComponent
  },
  {
    path: 'app-statement',
    component: StatementComponent
  },
  {
    path: 'app-hpage',
    component: HpageComponent
  }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
