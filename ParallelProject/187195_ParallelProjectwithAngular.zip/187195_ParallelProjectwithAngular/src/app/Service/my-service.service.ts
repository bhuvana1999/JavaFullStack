import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../Models/Customer';
import { Transactions } from '../Models/Transactions';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  isLogin:boolean=true;
  customers:Customer[]=[];
  transactions:Transactions[]=[];
  tempTransaction:Transactions[]=[];
  fetched:boolean=false;
  fetchedT:boolean=false;

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchCustomers();
    this.fetchTransactions();
  }

  fetchCustomers()
  {
    this.http.get('./assets/Customer.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Customer(o.account,o.name,o.phone,o.password,o.city,o.balance);
      this.customers.push(e);
    }
  }

  fetchTransactions()
  {
    this.http.get('./assets/Transactions.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedT)
        {
          this.convertTransaction(data);
          this.fetchedT=true;
        }
      }
    );
  }

  convertTransaction(dataT:any)
  {
    for(let o of dataT)
    {
      let e=new Transactions(o.tid,o.taccount_sender,o.taccount_reciver,o.tamount,o.ttype);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }

  getCustomers():Customer[]
  {
    return this.customers;
  }

  getTransactions():Transactions[]
  {
    return this.transactions;
  }

  bStatement(account:string):Transactions[]{
    this.tempTransaction=[];
    for(let i=0;i<this.transactions.length;i++)
    {
      let e=this.transactions[i];
      if(account==e.taccount_sender)
      {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }

  add(e:Customer){
    this.customers.push(e);
    var myJSON = JSON.stringify(this.customers);
  }

  addTransaction(e:Transactions){
    this.transactions.push(e);
  }

  showBalance(data:Customer):number{
    let account = data.account; 
    for(let i=0;i<this.customers.length;i++)
      {
        if(account == this.customers[i].account)
        {
          let balance=this.customers[i].balance;
          return balance;
        }else{
          continue;
        }
      }
      alert("Wrong login details!")
  }

  depositeBalance(account_first:number,balance:number){
      console.log(account_first,balance)

      for(let i=0;i<this.customers.length;i++)
      {
        if(account_first == this.customers[i].account)
        {
          let depositeB:number=this.customers[i].balance;
          this.customers[i].balance=parseInt(depositeB.toString()) + parseInt(balance.toString());
          alert("Amount added to "+account_first+"\nCurrent Balance : "+this.customers[i].balance);
          break;
        }
      }
  }
  
  withdrawBalance(account_first:number,balance:number){
    for(let i=0;i<this.customers.length;i++)
    {
      console.log(this.customers[i])
      if(account_first == this.customers[i].account)
      {
        let withdrawB:number=this.customers[i].balance;
        this.customers[i].balance=parseInt(withdrawB.toString()) - parseInt(balance.toString());
        alert("Amount Withdrawn from "+account_first+"\nCurrent Balance : "+this.customers[i].balance);
        break;
      }
    }
  }

  login(data:Customer):boolean
  {
    let account=data.account;
    let password=data.password;

    for(let a of this.customers)
    {
      console.log(this.customers)
      if(account == a.account && password == a.password)
      {
       
        alert("Login details matched!")
        this.isLogin=!this.isLogin;
        return true;
      }else {
        continue;
      }
      
    }
    return false;
  }
 
}

