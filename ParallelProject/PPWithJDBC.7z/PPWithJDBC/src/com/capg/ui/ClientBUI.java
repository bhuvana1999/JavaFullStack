package com.capg.ui;

import java.util.Scanner;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;

import com.capg.bean.Bank;
import com.capg.bean.Transaction;
import com.capg.exception.BankUserInputException;
import com.capg.service.BankWalletServiceImpl;
import com.capg.service.IBankWalletService;
import com.capg.validation.BankUserIOValidation;



public class ClientBUI {


    public static void main(String args[]) {
        Bank bank;
        Transaction transaction = new Transaction();
        BankUserIOValidation validation = new BankUserIOValidation();
        IBankWalletService bankWalletService = new BankWalletServiceImpl();
        Scanner scanner = new Scanner(System.in);
        int choice;
        
        LocalDate date = LocalDate.now();
        LocalTime time = LocalTime.now();
        while (true) {
        	System.out.println("****************************************************************");

			System.out.println("\t\t\tPay Wallet");
			System.out.println("****************************************************************");
			System.out.println();
			System.out.println(
					" 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transaction \n 7. Exit \n \n*************************************************************** \n");
				System.out.println("Enter Your Choice : ");
            choice = scanner.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Enter your name:\n");
                String name = scanner.next();
                try {
                    while (!BankUserIOValidation.checkName(name)) {
                        System.out.print(" Invalid Name \n");
                        System.out.print("Enter your name : ");
                        name = scanner.next();
                    }
                } catch (BankUserInputException e) {
                   
                    e.printStackTrace();
                }
                System.out.println("Enter your date of birth DD/MM/YYYY");
                String dob = scanner.next();
                System.out.println("Enter your mobile number");
                String phno = scanner.next();
                try {
                    while (!BankUserIOValidation.checkPhoneNumber(phno)) {
                        System.out.print("Enter your phone number : ");
                        phno = scanner.next();
                    }
                } catch (BankUserInputException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("Enter your pin (four digit)");
                int pin = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkPIN(pin)) {
                        System.out.print("Enter your PIN : ");
                        pin = scanner.nextInt();
                    }
                } catch (BankUserInputException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("Enter amount");
                long amt = scanner.nextLong();
                int acno = (int) ((Math.random()) * 1000000000);
                int tranid = (int) ((Math.random()) * 100000);
                bank = new Bank(acno, name, dob, phno, pin, amt);
                transaction = new Transaction(tranid, acno, "Account Created Sucessfully...!!! Date : " + date + " Time : " + time
                        + " Your balance is " + amt);
                bankWalletService.addAccount(bank, transaction);
                System.out.println("Your Account Created Sucessfully...!!!\n Your Account number is " + acno);
                break;
            case 2:
                System.out.println("Enter your account number ");
                int accountNumber = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkAccNo(accountNumber)) {
                        System.out.print("Enter correct Account Number: ");
                        accountNumber = scanner.nextInt();
                    }
                } catch (BankUserInputException e2) {
                    // TODO Auto-generated catch block
                    e2.printStackTrace();
                }
                String message = bankWalletService.checkBalance(accountNumber);
                System.out.println(message);
                break;
            case 3:
                System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
                int accountNumber1 = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkAccNo(accountNumber1)) {
                        System.out.print("Enter correct Account Number: ");
                        accountNumber1 = scanner.nextInt();
                    }
                } catch (BankUserInputException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                System.out.println("ENTER THE AMOUNT YOU NEED TO DEPOSIT : ");
                long amount = scanner.nextLong();
                int tranidd = (int) ((Math.random()) * 100000);
                transaction = new Transaction(tranidd, accountNumber1, "Ammount Deposited. Date : " + date + " Time : "
                        + time + " Rs." + amount + " was deposited successfully.");
                String message1 = bankWalletService.depositMoney(accountNumber1, amount, transaction);
                System.out.println(message1);
                break;
            case 4:
                System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
                int accountNumberr = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkAccNo(accountNumberr)) {
                        System.out.print("Enter correct Account Number: ");
                        accountNumberr = scanner.nextInt();
                    }
                } catch (BankUserInputException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("ENTER THE AMOUNT YOU NEED TO WITHDRAW : ");
                long amountt = scanner.nextLong();
                int tranId = (int) ((Math.random()) * 100000);
                transaction = new Transaction(tranId, accountNumberr, "Ammount Withdrawn. Date : " + date + " Time : "
                        + time + " Rs." + amountt + " was withdrawn successfully.");
                String messagee = bankWalletService.withdrawMoney(accountNumberr, amountt, transaction);
                System.out.println(messagee);
                break;
            case 5:
                System.out.println("Enter your account number : ");
                int accountNumber01 = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkAccNo(accountNumber01)) {
                        System.out.print("Enter correct Account Number: ");
                        accountNumber01 = scanner.nextInt();
                    }
                } catch (BankUserInputException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println("Enter amount : ");
                long amount01 = scanner.nextLong();
                System.out.println("Enter recevier account number: ");
                int accountNumber02 = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkAccNo(accountNumber02)) {
                        System.out.print("Enter correct Account Number: ");
                        accountNumber02 = scanner.nextInt();
                    }
                } catch (BankUserInputException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                int tranid1 = (int) ((Math.random()) * 100000);
                int tranid2 = (int) ((Math.random()) * 100000);
                Transaction trans1 = new Transaction(tranid1, accountNumber01, "Ammount Sent. Date : " + date
                        + " Time : " + time + " Rs." + amount01 + " was set to " + accountNumber02 + " successfully.");
                Transaction trans2 = new Transaction(tranid2, accountNumber02,
                        "Ammount Recived. Date : " + date + " Time : " + time + " Rs." + amount01 + " was recived from "
                                + accountNumber02 + " successfully.");
                String messages = bankWalletService.transferMoney(accountNumber01, amount01, accountNumber02, trans1,
                        trans2);
                System.out.println(messages);
                break;
            case 6:
                System.out.println("Enter your account number  : ");
                int accountNumbers = scanner.nextInt();
                try {
                    while (!BankUserIOValidation.checkAccNo(accountNumbers)) {
                        System.out.print("Enter correct Account Number: ");
                        accountNumbers = scanner.nextInt();
                    }
                } catch (BankUserInputException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                System.out.println(bankWalletService.getTransactionDetails(accountNumbers));
                break;
            case 7:
                System.out.println("Thank You...!!! Visit again...!!!");
                break;
            default:
                System.out.println("Invalid choice." + "\n" + " Enter Valid choice");

 

            }
        }

 

    }

 

}



