package com.capg.bean;

public class Bank {

	 

    private int acNo;

 

    private String name;

 

    private String dob;

 

    private String phno;

 

    private int pin;

 

    private long balance;

 

    public Bank(int acNo, String name, String dob, String phno, int pin, long balance) {
        super();
        this.acNo = acNo;
        this.name = name;
        this.phno = phno;
        this.dob = dob;
        this.pin = pin;
        this.balance = balance;  

 

    }

 

    public Bank() {

 

    }

 

    public int getAcNo() {
        return acNo;
    }

 

    public void setAcNo(int acNo) {
        this.acNo = acNo;
    }

 

    public String getName() {
        return name;
    }

 

    public void setName(String name) {
        this.name = name;
    }

 

  
 

    public String getPhno() {
		return phno;
	}



	public void setPhno(String phno) {
		this.phno = phno;
	}



	public String getDob() {
        return dob;
    }

 

    public void setDob(String dob) {
        this.dob = dob;
    }

 

    public int getPin() {
        return pin;
    }

 

    public void setPin(int pin) {
        this.pin = pin;
    }

 

    public long getBalance() {
        return balance;
    }

 

    public void setBalance(long balance) {
        this.balance = balance;
    }

 

    @Override
    public String toString() {
        return "Bank acNo=" + acNo + ", name=" + name + ", phno=" + phno + ", dob=" + dob + ", pin=" + pin
                + ", balance=" + balance;
    }

 

}
 