package com.dao;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Test;
import com.bean.BankEntity;

public class JUnit {
	    EntityManager con;
	    ConnectionDatabase cd=new ConnectionDatabase();
	    BankEntity bb1;
	    
	    @Test
	    public void getBalance() { 
	        con = cd.getConnection();
	        con.getTransaction().begin();
	        BankEntity emp1=(BankEntity) con.find(BankEntity.class,new Long(1));
	        con.getTransaction().commit();
	        long observed= emp1.getBalance();
	        long expected=1000;//correct
	        Assert.assertEquals(expected, observed);
	    }

	    @Test
	    public void getInfo() {
	        con = cd.getConnection();
	        con.getTransaction().begin();
	        BankEntity emp1=(BankEntity) con.find(BankEntity.class,new Long(1));
	        con.getTransaction().commit();
	        long observed= emp1.getBalance();
	        long expected=1000;//correct
	        Assert.assertEquals(expected, observed);
	    }
}
