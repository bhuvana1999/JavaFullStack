package com.dao;

import com.bean.BankEntity;

public interface BankDaoI {
	
	long getBalance(long accNo) ;

	void setBalance(long accNo, long bal, String st);


	boolean checkPassword(String str,long accNo) ;

	boolean checkAccNo(long accNo);

	long setData(BankEntity bb);

	String getTransaction(long accNo);

	BankEntity getInfo(long accNo);
}
