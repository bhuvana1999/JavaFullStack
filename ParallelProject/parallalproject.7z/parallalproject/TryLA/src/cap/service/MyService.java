package cap.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;
import cap.bean.MyBean;
import cap.bean.MyTransaction;
import cap.dao.MyDao;
class MyException extends Exception {
	String s1;

	MyException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

}

public class MyService implements MyServiceIntF {
	MyDao daoobj = new MyDao();
	MyBean bobj = new MyBean();
	Scanner sc = new Scanner(System.in);

	public void CreateAccount(MyBean createobj) throws ClassNotFoundException, SQLException {
		daoobj.CreateAccount(createobj);

	}

	public float showBalance(long accNo)throws ClassNotFoundException, SQLException {
		return daoobj.showBalance(accNo);
	}

	public float deposit(long accNo, float depositAmount) throws ClassNotFoundException, SQLException {

		return daoobj.deposit(accNo, depositAmount);
	}

	public float withdraw(long accNo, float withdrawAmount) {
		return daoobj.withdraw(accNo, withdrawAmount);
	}

	public float fundTransfer(long accNo, long accNo1, float balance) throws ClassNotFoundException, SQLException {

		return daoobj.fundTransfer(accNo, accNo1, balance);
	}

	public ArrayList<MyTransaction> printTransaction(long accNo) throws ClassNotFoundException, SQLException {
		return daoobj.printTransaction(accNo);
	}

	// checking amount
	public float amountcheck(float amount) {
		while (true) {
			if (amount < 100) {
				System.out.println("Amount should not be less than 100");
				System.out.println("Enter amount again");
				amount = sc.nextFloat();
			} else {
				return amount;
			}

		}
	}

	// checking phno
	public long numbercheck(long number) {
		while (true) {
			if (String.valueOf(number).length() > 10 || String.valueOf(number).length() < 10) {
				System.out.println("Enter valid mobile number");
				number = sc.nextLong();
			} else {
				return number;
			}

		}
	}

	// Checking name
	public String namecheck(String name) {
		while (true) {
			if (Pattern.matches(("([A-Z])*([a-z])*"), name)) {
				return name;
			} else {
				System.out.println("Name should have only alphabets");
				System.out.println("Enter your name again");
				name = sc.next();
			}
		}
	}
	
	
}
