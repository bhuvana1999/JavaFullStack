package cap.service;

import java.sql.SQLException;
import java.util.ArrayList;

import cap.bean.MyBean;
import cap.bean.MyTransaction;

public interface MyServiceIntF {
	public void CreateAccount(MyBean createobj) throws ClassNotFoundException, SQLException;
	public float showBalance(long accNo) throws ClassNotFoundException, SQLException;
	public float deposit(long accNo,float depositAmount) throws ClassNotFoundException, SQLException;
	public float withdraw(long accNo, float withdrawAmount);
	public float fundTransfer(long accNo, long accNo1, float balance) throws ClassNotFoundException, SQLException;
	public  ArrayList<MyTransaction>  printTransaction(long accNo) throws ClassNotFoundException, SQLException ;
	public float amountcheck(float amount);
	public long numbercheck (long number);
	public String namecheck (String name);
	
}
