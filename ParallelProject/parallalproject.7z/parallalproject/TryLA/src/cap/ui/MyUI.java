package cap.ui;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import cap.bean.MyBean;
import cap.bean.MyTransaction;
import cap.service.MyService;

public class MyUI {

	public int getOption(Scanner sc) {
		try {
			int ch = sc.nextInt();
			return ch;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		MyService serobj = new MyService();

		Scanner sc = new Scanner(System.in);
		int ch;
		do {
			System.out.println("*********************");
			System.out.println(
					"1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit");
			System.out.println("*********************");
			System.out.println("enter your choice");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.print("Enter Name: ");
				String name = serobj.namecheck(sc.next());
				System.out.print("Enter Mobile No.: ");
				long mobileNo = serobj.numbercheck(sc.nextLong());
				Random r = new Random();
				long accNo = r.nextInt(1000000);
				System.out.print("Enter Balance: ");
				float balance = serobj.amountcheck(sc.nextFloat());
				MyBean createobj = new MyBean(accNo, name, mobileNo, balance);
				System.out.println("Welcome " + name + "\nYour Account created with Account Number: " + accNo
						+ "\nyour initial balance " + balance);
				serobj.CreateAccount(createobj);
				break;
			case 2:
				System.out.print("Enter Account Number: ");
				accNo = sc.nextLong();
				balance = serobj.showBalance(accNo);
				System.out.println("Your current balance is " + balance);
				break;
			case 3:
				System.out.print("Enter Account Number: ");
				accNo = sc.nextLong();
				System.out.print("Enter Deposit Amount: ");
				float depositAmount = serobj.amountcheck(sc.nextFloat());
				balance = serobj.deposit(accNo, depositAmount);
				System.out.println("Deposited Sucessfully");
				System.out.println("Your New balance: " + balance);

				break;
			case 4:
				System.out.print("Enter Account Number: ");
				accNo = sc.nextLong();
				System.out.print("Enter Withdraw Amount: ");
				float withdrawAmount = serobj.amountcheck(sc.nextFloat());
				balance = serobj.withdraw(accNo, withdrawAmount);
				System.out.println("Withdrawn sucessfully");
				System.out.println("Your remaining balance: " + balance);

				break;
			case 5:
				System.out.println("Enter Source Account Number: ");
				accNo = sc.nextLong();
				System.out.println("Enter Destination Account Number: ");
				long accNo1 = sc.nextLong();
				System.out.println("Enter Amount to transfer: ");
				balance = serobj.amountcheck(sc.nextFloat());
				float amount = serobj.fundTransfer(accNo, accNo1, balance);
				System.out.println("Amount transferred Sucessfully");
				System.out.println("After transaction your current balance is " + amount);
				break;
			case 6:

				System.out.print("Enter Account Number: ");
				accNo = sc.nextLong();
				List<?> l = serobj.printTransaction(accNo);
				Iterator<?> i = l.iterator(); {
				while (i.hasNext()) {
					MyTransaction mt = (MyTransaction) i.next();
					System.out.println("Transaction ID: " + mt.getTransId());
					System.out.println("From Account: " + mt.getAccNofrom());
					System.out.println("To Account: " + mt.getAccnoto());
					System.out.println("Date of transaction: " + mt.getDate());
					System.out.println("Transfered amount: " + mt.getTransAmount());
					System.out.println("Balance: " + mt.getBalance());
					System.out.println("Transaction Type: " + mt.getTransInfo());
				}
			}
				break;
			case 7:
				System.out.println("Thank You for using Our Application...!");
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid choice ");
				System.out.println("Thank You...!");
				System.exit(0);
			}
		} while (ch != 7);
		sc.close();
	}

}
