package cap.bean;

public class MyTransaction {
	private int transId;
	private long accNofrom;
	private long accnoto;
	private String date;
	private String transInfo;
	private float balance;
	private float TransAmount;
	
	public float getTransAmount() {
		return TransAmount;
	}
	public void setTransAmount(float transAmount) {
		TransAmount = transAmount;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public long getAccNofrom() {
		return accNofrom;
	}
	public void setAccNofrom(long accNofrom) {
		this.accNofrom = accNofrom;
	}
	public long getAccnoto() {
		return accnoto;
	}
	public void setAccnoto(long accnoto) {
		this.accnoto = accnoto;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTransInfo() {
		return transInfo;
	}
	public void setTransInfo(String transInfo) {
		this.transInfo = transInfo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	//constructor
	public MyTransaction(int transId, long accNofrom, long accnoto, String date, String transInfo,float balance,float TransAmount) {
		super();
		this.transId = transId;
		this.accNofrom = accNofrom;
		this.accnoto = accnoto;
		this.date = date;
		this.transInfo = transInfo;
		this.balance = balance;
		this.TransAmount=TransAmount;
	
	}
	public MyTransaction() {
		super();
	}
	@Override
	public String toString() {
		return "transId=" + transId + ", accNofrom=" + accNofrom + ", accnoto=" + accnoto + ", date=" + date + ", transInfo=" + transInfo + ", balance=" + balance
				+ ", TransAmount=" + TransAmount ;
	}
	
	}
	
	
	
	
	
	


