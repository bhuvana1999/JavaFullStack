package cap.bean;

public class MyBean {
	private String name;
	private long mobileNo;
	private float balance;
	private float depositAmount;
	private float withdrawAmount;
	private long accNo;
	//getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public float getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(float depositAmount) {
		this.depositAmount = depositAmount;
	}
	public float getWithdrawAmount() {
		return withdrawAmount;
	}
	public void setWithdrawAmount(float withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	//constructor
	public MyBean(String name, long mobileNo, float balance, float depositAmount, float withdrawAmount, long accNo) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.balance = balance;
		this.depositAmount = depositAmount;
		this.withdrawAmount = withdrawAmount;
		this.accNo = accNo;
	}
	public MyBean(long accNo, String name, long mobileNo, float balance)
	{
		this.name = name;
		this.mobileNo = mobileNo;
		this.balance = balance;
		this.accNo = accNo;
	}
	public MyBean()
	{
		super();
	}
	
	
}