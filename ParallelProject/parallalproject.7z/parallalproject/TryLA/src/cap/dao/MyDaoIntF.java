package cap.dao;

import java.util.ArrayList;
import java.util.HashMap;

import cap.bean.MyBean;
import cap.bean.MyTransaction;

public interface MyDaoIntF {
	public void addAccount(MyBean obj);
	public void mytransaction(MyTransaction transobj);
	public HashMap<Long, MyBean> hm();
	 public HashMap<MyTransaction,Long>hm1();
	 public void CreateAccount(MyBean obj) ;
	 public float showBalance(long accNo);
	 public float deposit(long accNo, float depositAmount);
	 public float withdraw(long accNo, float withdrawAmount);
	 public float fundTransfer(long accNo, long accNo1, float balance);
	 public ArrayList<MyTransaction> printTransaction(long accNo);
}
