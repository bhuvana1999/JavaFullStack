package cap.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import cap.bean.MyBean;
import cap.bean.MyTransaction;
import cap.service.MyService;

public class MyDao {
MyBean obj;
MyService ser;
MyTransaction tranobj;

HashMap<Long,MyBean>hm=new HashMap<Long, MyBean>();
HashMap<MyTransaction,Long> hm1=new HashMap<MyTransaction,Long>();//for transaction

public void addAccount(MyBean obj)
{
	this.obj=obj;
	hm.put(obj.getAccNo(), obj);
	System.out.println(hm);
	
}
public void mytransaction(MyTransaction transobj)
{
	this.tranobj=transobj;
	System.out.println(hm1);
}
public HashMap<Long, MyBean> hm()
{		                                       
	return hm;
}
 public HashMap<MyTransaction,Long>hm1()
{
	return hm1;
	
}
 
 public void CreateAccount(MyBean obj) 
	{
		hm.put(obj.getAccNo(),obj);
		obj=(MyBean )hm.get(obj.getAccNo());
	}
public float showBalance(long accNo) {
	obj=hm.get(accNo);
	float balance=obj.getBalance();
	return balance;
}
 
public float deposit(long accNo, float depositAmount) {
	obj=hm().get(accNo);
	float balance=obj.getBalance();
	float sum=balance+depositAmount;
	obj.setBalance(sum);
	hm.put(accNo,obj);
	
	MyTransaction mt=new MyTransaction();
	mt.setAccNofrom(accNo);
	Random r=new Random();
	int TransId=r.nextInt(1000);
	mt.setTransId(TransId);
	mt.setTransInfo("deposit");
	mt.setBalance(balance);
	mt.setTransAmount(depositAmount);
	DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
	LocalDateTime now=LocalDateTime.now();
	mt.setDate(dt.format(now));
	hm1.put(mt, accNo);
	return sum;
		
}
public float withdraw(long accNo, float withdrawAmount) {
	
	obj=hm().get(accNo);
	float balance=obj.getBalance();
		float diff=balance-withdrawAmount;
		obj.setBalance(diff);
		hm.put(accNo,obj);
		MyTransaction mt=new MyTransaction();
		mt.setAccNofrom(accNo);
		Random r=new Random();
		int TransId=r.nextInt(1000);
		mt.setTransId(TransId);
		mt.setTransInfo("withdraw");
		mt.setBalance(balance);
		mt.setTransAmount(withdrawAmount);
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now=LocalDateTime.now();
		mt.setDate(dt.format(now));
		hm1.put(mt, accNo);
		return diff;
}
public float fundTransfer(long accNo, long accNo1, float balance) {
	 obj=hm.get(accNo);
	 float bal1=obj.getBalance();
	 float bal2=bal1-balance;
	 obj.setBalance(bal2);
	 hm.put(accNo,obj);
	 
	 obj=hm.get(accNo1);
	 float bal3=obj.getBalance();
	 float bal4=bal3+balance;
	 obj.setBalance(bal4);
	 hm.put(accNo1,obj);
	 
	 MyTransaction mt=new MyTransaction();
		mt.setAccNofrom(accNo);
		mt.setAccnoto(accNo1);
		Random r=new Random();
		int TransId=r.nextInt(10000);
		mt.setTransId(TransId);
		mt.setTransInfo("Transfer");
		mt.setTransAmount(balance);
		mt.setBalance(balance);
		DateTimeFormatter dt=DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now=LocalDateTime.now();
		mt.setDate(dt.format(now));
		hm1.put(mt, accNo);
		
	 return bal2;
}

public ArrayList<MyTransaction> printTransaction(long accNo) {
	ArrayList<MyTransaction> al=new ArrayList<>(hm1.keySet());
	return al;
}

}



