package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capg.entities.TransactionBean;

public interface TransactionDao extends JpaRepository<TransactionBean, Integer> {
	
	@Query("from TransactionBean where accNo=?1")
	List<TransactionBean> printTransaction(Long accNo);

}
