package com.capg.bean;

import javax.persistence.*;


@Entity
@Table(name="Transaction")
public class TransactionBean {
	@Column(name="transactionType",length=20)
	private String transactionType;
	
	
	@Id
	private long transactionId;
	
	@Column(name="Amount" ,length=20)
	private int amount;

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
   @ManyToOne
   @JoinColumn(name="accountNo",referencedColumnName="AccNo")
   private PayWalletBean bank;
   
   @Override
public String toString() {
	return "-----Transaction-----\n[\n transactionType= " + transactionType + ",\n transactionId= " + transactionId + ",\n amount= " + amount
			+ ",\n Account= " + bank.getAccountNo() + ",\n FromAccount= " + FromAccount + "\n]";
}

public PayWalletBean getBank() {
		return bank;
	}

	public void setBank(PayWalletBean bank) {
		this.bank = bank;
	}
	@Column(name="fromaccount")
	private Long FromAccount;

	public Long getFromAccount() {
		return FromAccount;
	}

	public void setFromAccount(Long otherAccount) {
		FromAccount = otherAccount;
	}

	
}
