package com.capg.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.bean.PayWalletBean;
import com.capg.bean.TransactionBean;

@Repository("PayWalletDao")
@Transactional
public class PayWalletDao implements PayWalletInterface {


	@PersistenceContext
	private EntityManager em;

	public void setEntityManager(EntityManager em) {
		this.em = em;
	}
	Random rand = new Random();
	
	@Override
	public boolean createAccount(PayWalletBean bean) {
		em.persist(bean);
		return true;

	}

	@Override
	public int showBalance(long accountNo) {
		int balance = 0;
		PayWalletBean bean = em.find(PayWalletBean.class, accountNo);
		balance = bean.getBalance();
		return balance;
	}

	@Override
	public int depositBalance(long accountNo, int deposit) {
		int balance = 0;
		PayWalletBean bean = em.find(PayWalletBean.class, accountNo);
		int bal = bean.getBalance();
		int bal1 = bal + deposit;
		bean.setBalance(bal1);
		TransactionBean tran = new TransactionBean();
		tran.setAmount(deposit);
		tran.setTransactionId(rand.nextInt(100000));
		tran.setTransactionType("deposit");
		tran.setBank(bean);
		em.persist(tran);
		em.merge(bean);

		return bal1;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance = 0;
		PayWalletBean bean = em.find(PayWalletBean.class, accountNo);
		int bal = bean.getBalance();
		int bal1 = bal - withdraw;
		bean.setBalance(bal1);
		
		TransactionBean tran = new TransactionBean();
		tran.setAmount(withdraw);
		tran.setTransactionId(rand.nextInt(100000));
		tran.setTransactionType("withdraw");
		tran.setBank(bean);
		em.persist(tran);
		em.merge(bean);

		return bal1;

	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean b = false;
		PayWalletBean bean = em.find(PayWalletBean.class, accountNo);
		PayWalletBean bean1 = em.find(PayWalletBean.class, accno);
		if (bean.getBalance() <= amount) {
			b = false;
		} else {
			int bal = bean.getBalance();
			int bal1 = bean1.getBalance();
			int bal2 = bal1 + amount;
			int bal3 = bal - amount;
			
			bean1.setBalance(bal2);
			TransactionBean tran = new TransactionBean();
			tran.setAmount(amount);
			tran.setTransactionId(rand.nextInt(100000));
			tran.setTransactionType("fund transfer");
			tran.setBank(bean1);
			tran.setFromAccount(accno);
			em.persist(tran);
			
			bean.setBalance(bal3);
			TransactionBean tran1 = new TransactionBean();
			tran1.setAmount(amount);
			tran1.setTransactionId(rand.nextInt(100000));
			tran1.setTransactionType("fund transfer");
			tran1.setBank(bean);
			tran.setFromAccount(accountNo);
			em.persist(tran1);
			b = true;
		}
		return b;
	}

	@Override
	public boolean validateAccount(long accountNo, String password) {
		boolean b = false;
		
		PayWalletBean bean1 = em.find(PayWalletBean.class, accountNo);
		if(bean1==null)
		{
			b=false;
		}
		else
		{
	   String pass = bean1.getPassword();
		System.out.println(pass);
		if (password.equals(pass)) {
			b = true;
		}
		else
		{
			b =false;
		}
		
		}
		return b;
	}

	@Override
	public List<TransactionBean> getTransactions(long accountNo) {
		PayWalletBean bank = em.find(PayWalletBean.class, accountNo);
		TypedQuery<TransactionBean> query = em.createQuery("Select t from TransactionBean as t where t.bank=:bank",
				TransactionBean.class);
		query.setParameter("bank", bank);
		List<TransactionBean> trans = query.getResultList();
		return trans;
	}

	
}